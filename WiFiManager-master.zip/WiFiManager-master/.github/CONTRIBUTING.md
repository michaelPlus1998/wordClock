## Contributing PRs and ISSUES

The development branch is the active branch, no features or bugs will be fixed against master ( hotfixes may be considered ).

Please test against development branch before submitting issues, issues against master will be closed, 

PRs against master may be kept open if provides something useful to other members.

Please open issues before sumbitting PRs against development, as commits might be occuring very frequently.

### Documentation is in progress
https://github.com/tzapu/WiFiManager/issues/500
